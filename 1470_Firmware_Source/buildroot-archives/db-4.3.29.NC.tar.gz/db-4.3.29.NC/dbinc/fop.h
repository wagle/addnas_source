/*-
 * See the file LICENSE for redistribution information.
 *
 * Copyright (c) 2001-2004
 *	Sleepycat Software.  All rights reserved.
 *
 * $Id: fop.h,v 11.5 2004/01/28 03:36:02 bostic Exp $
 */

#ifndef	_FOP_H_
#define	_FOP_H_

#include "dbinc_auto/fileops_auto.h"
#include "dbinc_auto/fileops_ext.h"

#endif /* !_FOP_H_ */
