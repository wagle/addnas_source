/* $OpenBSD: version.h,v 1.49 2007/03/06 10:13:14 djm Exp $ */

#define SSH_VERSION	"OpenSSH_4.6"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
